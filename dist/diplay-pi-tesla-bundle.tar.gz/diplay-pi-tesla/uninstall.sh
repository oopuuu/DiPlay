#!/bin/bash
set -e
if [ "$EUID" -ne 0 ]; then
    echo "[-] 请以 root 权限运行: sudo bash $0"
    exit 1
fi
echo "[*] 正在卸载 DiPlay-Pi..."
systemctl stop diplay-pi diplay-gui diplay-bt diplay-airplay diplay-iap2 2>/dev/null || true
systemctl disable diplay-pi diplay-gui diplay-bt diplay-airplay diplay-iap2 2>/dev/null || true
rm -f /etc/systemd/system/diplay-*.service
systemctl daemon-reload
rm -rf /opt/diplay
echo "[✓] DiPlay-Pi 卸载完成。"
